#import <UIKit/UIKit.h>
#import "InjectedMenuController.h"
#import "InjectedOverlayOwnership.h"
#import "InjectedWindowSelection.h"
#import "InjectedOverlayAttachment.h"
#include "InjectedStartupPolicy.h"

@interface MizzeOverlayContainer : UIView
@property(nonatomic,weak) UIView *contentView;
@end
@implementation MizzeOverlayContainer
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *hit = [super hitTest:point withEvent:event];
    return (hit == self || hit == self.contentView) ? nil : hit;
}
@end

static BOOL setupPending = NO;
static NSUInteger setupAttempts = 0;
static const NSUInteger kMaxSetupAttempts = 60;
static InjectedStartup::Gate startupGate;
static void ScheduleInjectedOverlay(NSTimeInterval delay);

static void SetupInjectedOverlayMenu() {
    NSCAssert(NSThread.isMainThread, @"Overlay setup requires the main thread");
    UIApplication *app = UIApplication.sharedApplication;
    if (!app || MizzeOverlayOwner(app)) return;
    
    const NSTimeInterval now = NSProcessInfo.processInfo.systemUptime;
    UIWindow *gameWindow = MizzeFindGameWindow(app);
    if (!gameWindow) {
        if (++setupAttempts < kMaxSetupAttempts) ScheduleInjectedOverlay(1.0);
        return;
    }
    
    UIViewController *host = gameWindow.rootViewController;
    const BOOL attached = host.isViewLoaded && host.view.window == gameWindow &&
        !host.isBeingPresented && !host.isBeingDismissed && !host.transitionCoordinator;
        
    if (!startupGate.ready(app.applicationState == UIApplicationStateActive, attached,
        reinterpret_cast<uintptr_t>((__bridge void *)gameWindow), gameWindow.bounds.size.width,
        gameWindow.bounds.size.height, now)) {
        if (++setupAttempts < kMaxSetupAttempts) ScheduleInjectedOverlay(1.0);
        return;
    }

    // Bọc @try - @catch để nếu có lỗi UI, game không bị văng
    @try {
        MizzeOverlayContainer *overlay = [[MizzeOverlayContainer alloc] initWithFrame:host.view.bounds];
        overlay.backgroundColor = UIColor.clearColor;
        overlay.userInteractionEnabled = YES;
        
        if (!MizzeClaimOverlay(app, overlay)) return;

        InjectedMenuController *root = [InjectedMenuController new];
        root.gameWindow = gameWindow;
        overlay.contentView = root.view;
        
        if (!MizzeAttachChildOverlay(host, overlay, root)) {
            MizzeReleaseOverlay(app, overlay);
            if (++setupAttempts < kMaxSetupAttempts) ScheduleInjectedOverlay(2.0);
            return;
        }
        NSLog(@"[Mizze] Menu Overlay đã hiển thị thành công!");
    } @catch (NSException *exception) {
        NSLog(@"[Mizze] Lỗi khi tạo Menu (Đã chặn crash): %@", exception.reason);
    }
}

static void ScheduleInjectedOverlay(NSTimeInterval delay) {
    if (setupPending) return;
    setupPending = YES;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delay * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        setupPending = NO;
        SetupInjectedOverlayMenu();
    });
}

static void __attribute__((constructor)) StealthDylibEntryPoint() {
    // Chờ 15 giây để game vào trận đấu
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 15 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        @autoreleasepool {
            NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
            for (NSNotificationName name in @[UIApplicationDidFinishLaunchingNotification,
                                               UIApplicationDidBecomeActiveNotification,
                                               UIWindowDidBecomeKeyNotification]) {
                [center addObserverForName:name object:nil queue:NSOperationQueue.mainQueue
                                usingBlock:^(NSNotification *notification) {
                    setupAttempts = 0;
                    ScheduleInjectedOverlay(2.0);
                }];
            }
            ScheduleInjectedOverlay(2.0); 
        }
    });
}