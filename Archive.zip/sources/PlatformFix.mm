#import <Foundation/Foundation.h>

// Hàm bù trừ với ĐÚNG 3 dấu gạch dưới (___) ở đầu
__attribute__((visibility("default")))
int ___isPlatformVersionAtLeast(int major, int minor, int patch) {
    NSOperatingSystemVersion version;
    version.majorVersion = major;
    version.minorVersion = minor;
    version.patchVersion = patch;
    return [[NSProcessInfo processInfo] isOperatingSystemAtLeastVersion:version];
}